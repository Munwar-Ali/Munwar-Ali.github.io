Put your photos and project screenshots here, then point to them in js/config.js, e.g. image:"assets/images/my-project.png".
